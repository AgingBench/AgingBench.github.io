"""Minimal metrics namespace for the telemetry browser bundle.
Only aging_card is needed; the heavy g1/g2/g3 metrics modules are
intentionally omitted (they depend on numpy/scipy and aren't used
by the telemetry pipeline)."""
from .aging_card import build_aging_card  # noqa: F401
